export type Category = "Savannah" | "Primates" | "Water";

export type Place = {
  id: string;
  name: string;
  category: Category;
  region: string;
  tagline: string;
  story: string;
  highlights: string[];
  entryCost: string;
  carCost: string;
  transportTip: string;
  permitNote: string;
  image: string;
  gallery: string[];
  fit: string;
};

export const places: Place[] = [
  {
    id: "murchison",
    name: "Murchison Falls National Park",
    category: "Water",
    region: "North-western Uganda",
    tagline: "The Nile forced through a gorge, then a savannah that still feels unfinished.",
    story:
      "The river narrows to about seven metres and drops in one violent step. Above it, the northern bank is classic game country: elephants, giraffes, buffalo, lions, and long views to the delta. Most people split the day between the top of the falls, a launch to the base, and a game drive. It is a long way from Kampala, and worth the distance.",
    highlights: ["The falls themselves", "Nile launch cruise", "Northern-bank game drive"],
    entryCost: "UGX 30,000 (Citizen)",
    carCost: "UGX 30,000",
    transportTip: "Bus from Kampala to Masindi or Pakwach, or a private 4x4 via Karuma.",
    permitNote: "The launch and the falls hike sit on top of the gate fee.",
    image: "/media/ug/murchison-falls.jpg",
    gallery: ["/media/ug/falls-top.jpg", "/media/ug/murchison-bush.jpg"],
    fit: "object-center",
  },
  {
    id: "queen",
    name: "Queen Elizabeth National Park",
    category: "Savannah",
    region: "Western Uganda",
    tagline: "A channel full of hippos, crater lakes, and lions that learned the trees.",
    story:
      "Queen is not one view. The Kazinga Channel is a slow boat between banks of hippos, buffalo, and waterbirds. The Ishasha sector, further south, is where lions rest in fig trees. Between them: crater lakes, kob on the open plains, and the Kyambura gorge if you want chimpanzees as well. It sits on the main western highway, which is why it anchors so many loops.",
    highlights: ["Kazinga Channel boat", "Ishasha tree-climbing lions", "Crater lakes"],
    entryCost: "UGX 30,000 (Citizen)",
    carCost: "UGX 30,000",
    transportTip: "Direct highway via Mbarara–Kasese, or a public bus to Katunguru.",
    permitNote: "The boat cruise and any chimp tracking are separate from the gate.",
    image: "/media/ug/queen-baboon.jpg",
    gallery: [],
    fit: "object-center",
  },
  {
    id: "bwindi",
    name: "Bwindi Impenetrable National Park",
    category: "Primates",
    region: "South-western Uganda",
    tagline: "An ancient, steep forest holding about half the world's mountain gorillas.",
    story:
      "You do not drive to the gorillas. You walk, often for hours, on mud, roots, and nettle, with trackers ahead of you and a one-hour visit when you arrive. The park is split into sectors — Buhoma, Ruhija, Rushaga, Nkuringo — and the permit is not the same thing as the gate fee. Book it before you book anything else. The forest is also one of Africa's great bird places, if your knees survive the morning.",
    highlights: ["Mountain gorilla trek", "Forest walks", "Albertine Rift birds"],
    entryCost: "UGX 30,000 (Citizen)",
    carCost: "UGX 30,000",
    transportTip: "Kabale or Kisoro bus from Kampala, then a local taxi to the park gate.",
    permitNote: "A gorilla permit is booked apart from this gate fee, and it sells out.",
    image: "/media/ug/bwindi-gorilla.jpg",
    gallery: ["/media/ug/bwindi-close.jpg"],
    fit: "object-center",
  },
  {
    id: "kibale",
    name: "Kibale National Park",
    category: "Primates",
    region: "Western Uganda",
    tagline: "The primate capital: chimpanzees in a tall, bright forest near Fort Portal.",
    story:
      "Kibale has the highest density of primates in East Africa, and the walk people come for is chimpanzee tracking from Kanyanchu. It is usually kinder on the legs than Bwindi, and the forest feels open and loud. Bigodi wetland, just outside, is the half-day for birds and a village walk. Pair it with the crater lakes around Fort Portal rather than rushing straight back to the highway.",
    highlights: ["Chimpanzee tracking", "Bigodi wetland", "Thirteen primate species"],
    entryCost: "UGX 30,000 (Citizen)",
    carCost: "UGX 30,000",
    transportTip: "Fort Portal bus from Kampala, then a boda or taxi to Kanyanchu.",
    permitNote: "Chimpanzee permits are separate from the gate and should be reserved.",
    image: "/media/ug/kibale-chimp.jpg",
    gallery: ["/media/ug/kibale-alpha.jpg"],
    fit: "object-center",
  },
  {
    id: "kidepo",
    name: "Kidepo Valley National Park",
    category: "Savannah",
    region: "North-eastern Uganda",
    tagline: "A remote valley of ochre hills, buffalo, and animals you will not see further south.",
    story:
      "Kidepo is the park people describe after they have already done the others. The Narus Valley holds buffalo, elephant, zebra, and lions against a wall of mountains. Ostrich, cheetah, and bat-eared fox turn up here and almost nowhere else in the country. The road in is the point: it is long, and a 4x4 is not a suggestion. Flying to the park is the other honest option.",
    highlights: ["Narus Valley drives", "Dry mountain scenery", "Species rare elsewhere in Uganda"],
    entryCost: "UGX 30,000 (Citizen)",
    carCost: "UGX 30,000",
    transportTip: "Long-distance bus toward Kitgum or Moroto. A 4x4 is required inside the park.",
    permitNote: "Plan fuel, water, and a night. This is not a day trip from Kampala.",
    image: "/media/ug/kidepo-22.jpg",
    gallery: ["/media/ug/kidepo-1.jpg"],
    fit: "object-bottom",
  },
  {
    id: "mburo",
    name: "Lake Mburo National Park",
    category: "Savannah",
    region: "South-western Uganda",
    tagline: "The closest savannah to the capital, with zebras, a lake, and walks on foot.",
    story:
      "Mburo is the park you can reach before the day is gone. It is the only one in Uganda with impala, and one of the few with zebras. Boats work the lake, horses and guides work the bush, and you are allowed out of the car — which changes the scale of everything. If a first safari has to fit around a weekend, start here.",
    highlights: ["Zebras and impala", "Boat on the lake", "Walking safari"],
    entryCost: "UGX 30,000 (Citizen)",
    carCost: "UGX 30,000",
    transportTip: "Mbarara highway bus. Step off at Sanga gate or the Akageti junction.",
    permitNote: "Walks and boats are arranged at the gate and cost extra.",
    image: "/media/ug/mburo-zebra.jpg",
    gallery: [],
    fit: "object-center",
  },
  {
    id: "rwenzori",
    name: "Rwenzori Mountains National Park",
    category: "Water",
    region: "Western Uganda",
    tagline: "Glaciers on the equator. A trek, not a game drive.",
    story:
      "The Rwenzori are a world of their own: giant lobelia, soaking moss, and peaks the old maps called the Mountains of the Moon. This is hiking country above the Fort Portal–Kasese road. Trails are steep, weather turns in an hour, and you go with a guide. Come for the range, not for lions.",
    highlights: ["Guided mountain trails", "Afro-alpine plants", "Glaciated peaks"],
    entryCost: "Trekking tariff",
    carCost: "Ask at the trailhead",
    transportTip: "Kasese bus or train from Kampala, then a transfer to the Nyakalengija or Kilembe trailhead.",
    permitNote: "Fees follow the route and the number of days. They are not the savannah gate tariff.",
    image: "/media/ug/rwenzori.jpg",
    gallery: [],
    fit: "object-center",
  },
  {
    id: "jinja",
    name: "Jinja & the Source of the Nile",
    category: "Water",
    region: "Eastern Uganda",
    tagline: "Where the river leaves Lake Victoria. A town, not a national park.",
    story:
      "Jinja is the easy adventure east of Kampala: the source monument, a wide river, islands, and the rafting and kayak outfits that made the town famous. It is not a UWA savannah gate. You can be here and back in a day, or stay for the water. Go early if you want the lake calm and the viewpoint to yourself.",
    highlights: ["Source of the Nile", "River time", "A day east of the city"],
    entryCost: "Operator fees",
    carCost: "Town parking",
    transportTip: "Frequent taxis and buses from Kampala's Old Taxi Park. About two to three hours.",
    permitNote: "Rafting, cruises, and the source site are priced by the operator, not as a park gate.",
    image: "/media/ug/nile-jinja-2.jpg",
    gallery: [],
    fit: "object-center",
  },
];

export const categories: { id: "all" | Category; label: string }[] = [
  { id: "all", label: "All places" },
  { id: "Savannah", label: "Savannah" },
  { id: "Primates", label: "Primates" },
  { id: "Water", label: "Water & peaks" },
];

export type Experience = {
  id: string;
  title: string;
  kicker: string;
  text: string;
  placeId: string;
  image: string;
  fit: string;
  wide?: boolean;
};

export const experiences: Experience[] = [
  {
    id: "gorillas",
    title: "Gorilla trekking",
    kicker: "Bwindi",
    text: "One hour with a family, after a walk that can take the morning. The permit is the whole point of the trip — arrange it first.",
    placeId: "bwindi",
    image: "/media/ug/bwindi-close.jpg",
    fit: "object-center",
    wide: true,
  },
  {
    id: "chimps",
    title: "Chimpanzee tracking",
    kicker: "Kibale",
    text: "A forest walk with trackers who already know which community is feeding. Quieter logistics than the gorillas, same sense of privilege.",
    placeId: "kibale",
    image: "/media/ug/kibale-alpha.jpg",
    fit: "object-center",
  },
  {
    id: "cruise",
    title: "To the top of the falls",
    kicker: "Murchison",
    text: "Stand where the Nile gathers itself, then take the launch into the spray at the bottom. Do both. They are different rivers.",
    placeId: "murchison",
    image: "/media/ug/falls-top.jpg",
    fit: "object-center",
  },
  {
    id: "drive",
    title: "A slow game drive",
    kicker: "Northern bank",
    text: "Giraffes in a green plain, tracks of elephants, and the discipline to stop the car and wait. Dawn is the honest hour.",
    placeId: "murchison",
    image: "/media/ug/murchison-bush.jpg",
    fit: "object-center",
  },
  {
    id: "walk",
    title: "Out of the vehicle",
    kicker: "Lake Mburo",
    text: "Zebras at the scale of a footpath. Mburo is one of the few parks where a walking safari is the normal way to spend the afternoon.",
    placeId: "mburo",
    image: "/media/ug/mburo-zebra.jpg",
    fit: "object-center",
  },
  {
    id: "peaks",
    title: "Above the clouds",
    kicker: "Rwenzori",
    text: "A guided trail into moss and giant plants, with weather that does not care about your itinerary. Pack for wet rock.",
    placeId: "rwenzori",
    image: "/media/ug/rwenzori.jpg",
    fit: "object-center",
  },
];

export const seasons = [
  {
    id: "dry-a",
    months: "December – February",
    title: "Dry, and wide open",
    text: "Tracks are firm, grass is lower, and the savannah reads clearly. A strong time for Murchison, Queen, Kidepo, and Mburo.",
    monthsHit: [12, 1, 2],
  },
  {
    id: "long",
    months: "March – May",
    title: "The long rains",
    text: "The country turns deep green. Some murram roads slow down. Forest walks continue. Bring patience and a proper rain layer.",
    monthsHit: [3, 4, 5],
  },
  {
    id: "dry-b",
    months: "June – September",
    title: "The long dry",
    text: "The busiest, brightest window. Book gorilla permits early. Dust on the northern tracks, brilliant light on the falls.",
    monthsHit: [6, 7, 8, 9],
  },
  {
    id: "short",
    months: "October – November",
    title: "Short rains, green tracks",
    text: "Showers, fewer vehicles, and gorillas that do not take the season off. Give every transfer an extra hour.",
    monthsHit: [10, 11],
  },
];

export const heroSlides = [
  {
    src: "/media/ug/murchison-falls.jpg",
    place: "Murchison Falls",
    line: "The Nile, forced through a seven-metre gorge.",
  },
  {
    src: "/media/ug/bwindi-gorilla.jpg",
    place: "Bwindi Impenetrable",
    line: "A forest that still keeps the mountain gorillas.",
  },
  {
    src: "/media/ug/rwenzori.jpg",
    place: "The Rwenzori",
    line: "Mountains of the Moon, on the equator.",
  },
  {
    src: "/media/ug/mburo-zebra.jpg",
    place: "Lake Mburo",
    line: "Savannah you can reach before lunch.",
  },
];

export function placeById(id: string) {
  return places.find((place) => place.id === id);
}
