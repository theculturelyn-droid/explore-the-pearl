import { createFileRoute } from "@tanstack/react-router";
import { PearlGuide } from "@/components/pearl/page";

export const Route = createFileRoute("/")({
  component: PearlGuide,
  head: () => ({
    links: [{ rel: "preload", as: "image", href: "/media/ug/murchison-falls.jpg" }],
  }),
});
