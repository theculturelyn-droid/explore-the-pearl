import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import {
  ArrowRight,
  Check,
  ChevronLeft,
  ChevronRight,
  Menu,
  Search,
  X,
} from "lucide-react";
import {
  categories,
  experiences,
  heroSlides,
  placeById,
  places,
  seasons,
  type Category,
  type Place,
} from "@/data/guide";

const TRAIL_KEY = "pearl-trail";

type Overlay =
  | { kind: "none" }
  | { kind: "menu" }
  | { kind: "search" }
  | { kind: "trail" }
  | { kind: "place"; id: string };

function useTrail() {
  const [ids, setIds] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(TRAIL_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setIds(parsed.filter((item): item is string => typeof item === "string"));
        }
      }
    } catch {
      /* keep the empty trail */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(TRAIL_KEY, JSON.stringify(ids));
  }, [ids, ready]);

  function toggle(id: string) {
    setIds((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }

  function remove(id: string) {
    setIds((current) => current.filter((item) => item !== id));
  }

  return { ids, toggle, remove };
}

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setShown(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setShown(true);
          observer.disconnect();
        }
      },
      { threshold: 0.18 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return { ref, shown };
}

function Reveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const { ref, shown } = useReveal();
  return (
    <div ref={ref} className={`reveal ${shown ? "is-in" : ""} ${className}`}>
      {children}
    </div>
  );
}

export function PearlGuide() {
  const trail = useTrail();
  const [overlay, setOverlay] = useState<Overlay>({ kind: "none" });
  const [solid, setSolid] = useState(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<"all" | Category>("all");
  const [slide, setSlide] = useState(0);
  const railRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => {
      setSlide((current) => (current + 1) % heroSlides.length);
    }, 6800);
    return () => window.clearInterval(timer);
  }, []);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return places.filter((place) => {
      const inCategory = category === "all" || place.category === category;
      if (!inCategory) return false;
      if (!needle) return true;
      const hay = [
        place.name,
        place.tagline,
        place.story,
        place.region,
        place.transportTip,
        place.highlights.join(" "),
      ]
        .join(" ")
        .toLowerCase();
      return hay.includes(needle);
    });
  }, [query, category]);

  const searchHits = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return places;
    return places.filter((place) =>
      [place.name, place.region, place.tagline, place.highlights.join(" ")]
        .join(" ")
        .toLowerCase()
        .includes(needle),
    );
  }, [query]);

  function go(id: string) {
    setOverlay({ kind: "none" });
    window.setTimeout(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 40);
  }

  function nudgeRail(direction: number) {
    const rail = railRef.current;
    if (!rail) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    rail.scrollBy({
      left: direction * Math.round(rail.clientWidth * 0.8),
      behavior: reduce ? "auto" : "smooth",
    });
  }

  const open = overlay.kind !== "none";
  const activePlace = overlay.kind === "place" ? placeById(overlay.id) : undefined;
  const now = new Date().getMonth() + 1;

  return (
    <div className="min-h-svh bg-paper text-ink">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:bg-paper focus:px-4 focus:py-2"
      >
        Skip to content
      </a>

      <header
        className={`fixed inset-x-0 top-0 z-40 transition-colors duration-300 ${
          solid || open ? "border-b border-line bg-paper/95 text-ink" : "text-paper"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-10">
          <a href="#top" className="font-display text-2xl leading-none tracking-tight">
            The Pearl
          </a>
          <nav className="hidden items-center gap-8 text-sm font-medium md:flex">
            <button type="button" onClick={() => go("places")} className="hover:text-moss">
              Places
            </button>
            <button type="button" onClick={() => go("do")} className="hover:text-moss">
              Things to do
            </button>
            <button type="button" onClick={() => go("seasons")} className="hover:text-moss">
              Seasons
            </button>
            <button type="button" onClick={() => go("plan")} className="hover:text-moss">
              Plan
            </button>
          </nav>
          <div className="flex items-center gap-1">
            <button
              type="button"
              className="inline-flex h-11 items-center gap-2 px-3 text-sm font-medium"
              onClick={() => setOverlay({ kind: "trail" })}
            >
              Trail
              <span className="tabular-nums">{trail.ids.length}</span>
            </button>
            <button
              type="button"
              aria-label="Search the guide"
              className="inline-flex size-11 items-center justify-center"
              onClick={() => setOverlay({ kind: "search" })}
            >
              <Search className="size-5" strokeWidth={1.75} />
            </button>
            <button
              type="button"
              aria-label="Open menu"
              className="inline-flex size-11 items-center justify-center md:hidden"
              onClick={() => setOverlay({ kind: "menu" })}
            >
              <Menu className="size-5" strokeWidth={1.75} />
            </button>
          </div>
        </div>
      </header>

      <main id="main">
        <section id="top" className="relative min-h-svh overflow-hidden bg-ink text-paper">
          {heroSlides.map((item, index) => (
            <img
              key={item.src}
              src={item.src}
              alt={index === slide ? item.line : ""}
              aria-hidden={index !== slide}
              className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${
                index === slide ? "ken opacity-100" : "opacity-0"
              }`}
            />
          ))}
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-ink/20" />
          <div className="relative mx-auto flex min-h-svh max-w-7xl flex-col justify-end px-5 pt-24 pb-14 md:px-10 md:pb-16">
            <p className="text-xs font-medium tracking-widest uppercase">The Pearl of Africa</p>
            <h1 className="mt-4 max-w-5xl font-display text-hero">
              Make life
              <br />
              an adventure.
            </h1>
            <p className="mt-6 max-w-md text-base leading-relaxed text-paper/85 md:text-lg">
              Uganda, where savannah, rainforest, and the only waterfall the Nile makes share one border.
            </p>
            <div className="mt-10 flex flex-wrap items-end justify-between gap-6">
              <button
                type="button"
                onClick={() => go("places")}
                className="inline-flex h-12 items-center gap-3 border border-paper/40 px-5 text-sm font-medium transition-transform duration-150 active:scale-[0.96]"
              >
                Start with the places
                <ArrowRight className="size-4" />
              </button>
              <div className="flex items-center gap-4">
                <p className="max-w-56 text-right text-sm leading-snug text-paper/80">
                  <span className="block font-medium text-paper">{heroSlides[slide]?.place}</span>
                  {heroSlides[slide]?.line}
                </p>
                <div className="flex gap-2">
                  {heroSlides.map((item, index) => (
                    <button
                      key={item.place}
                      type="button"
                      aria-label={`Show ${item.place}`}
                      onClick={() => setSlide(index)}
                      className={`h-11 w-8 ${index === slide ? "opacity-100" : "opacity-45"}`}
                    >
                      <span
                        className={`block h-px w-full ${index === slide ? "bg-paper" : "bg-paper/70"}`}
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-24 md:px-10 md:py-32">
          <Reveal>
            <p className="text-xs font-medium tracking-widest text-moss uppercase">Welcome</p>
            <h2 className="mt-5 max-w-4xl font-display text-chapter">
              A country you can cross in a day, and still not finish.
            </h2>
            <p className="mt-8 max-w-2xl text-lg leading-relaxed text-muted">
              This is a field directory, not a brochure of slogans. Six national parks with citizen gate
              fees, the road that actually gets you there, and the permits that are not included.
            </p>
          </Reveal>
          <dl className="mt-16 grid gap-10 border-t border-line pt-10 sm:grid-cols-3">
            {[
              ["10", "National parks, from a weekend lake to a two-day frontier."],
              ["1,000+", "Bird species. The shoebill is only the famous one."],
              ["Half", "Of the world’s remaining mountain gorillas live in Bwindi."],
            ].map(([value, label]) => (
              <div key={value}>
                <dt className="font-display text-5xl text-ink">{value}</dt>
                <dd className="mt-3 max-w-xs text-sm leading-relaxed text-muted">{label}</dd>
              </div>
            ))}
          </dl>
        </section>

        <section className="grid md:grid-cols-3">
          {[
            {
              href: "places",
              kicker: "Places to go",
              title: "The parks",
              image: "/media/ug/kidepo-22.jpg",
              fit: "object-bottom",
            },
            {
              href: "do",
              kicker: "Things to do",
              title: "The hours that matter",
              image: "/media/ug/kibale-chimp.jpg",
              fit: "object-center",
            },
            {
              href: "plan",
              kicker: "Plan the journey",
              title: "Gates, roads, fees",
              image: "/media/ug/kidepo-1.jpg",
              fit: "object-center",
            },
          ].map((door) => (
            <button
              key={door.href}
              type="button"
              onClick={() => go(door.href)}
              className="group relative aspect-poster min-h-80 overflow-hidden text-left text-paper"
            >
              <img
                src={door.image}
                alt=""
                className={`absolute inset-0 h-full w-full ${door.fit} object-cover transition-transform duration-700 group-hover:scale-105`}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/15 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6 md:p-8">
                <p className="text-xs font-medium tracking-widest uppercase">{door.kicker}</p>
                <p className="mt-2 font-display text-4xl leading-none">{door.title}</p>
              </div>
            </button>
          ))}
        </section>

        <section id="places" className="scroll-mt-20 py-20 md:py-28">
          <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 md:flex-row md:items-end md:justify-between md:px-10">
            <Reveal>
              <p className="text-xs font-medium tracking-widest text-moss uppercase">Places to go</p>
              <h2 className="mt-3 font-display text-chapter">Where the country opens.</h2>
            </Reveal>
            <div className="flex flex-wrap gap-2">
              {categories.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCategory(item.id)}
                  className={`h-11 rounded-full px-4 text-sm font-medium transition-transform duration-150 active:scale-[0.96] ${
                    category === item.id
                      ? "bg-ink text-paper"
                      : "border border-line bg-paper text-ink"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mx-auto mt-8 flex max-w-7xl items-center justify-between gap-4 px-5 md:px-10">
            <label className="relative block max-w-md flex-1">
              <span className="sr-only">Filter places</span>
              <Search className="pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search parks, gorillas, buses, fees"
                className="h-12 w-full border border-line bg-paper pr-4 pl-11 text-sm outline-none focus:border-moss"
              />
            </label>
            <div className="hidden gap-2 sm:flex">
              <button
                type="button"
                aria-label="Previous places"
                onClick={() => nudgeRail(-1)}
                className="inline-flex size-11 items-center justify-center border border-line"
              >
                <ChevronLeft className="size-5" />
              </button>
              <button
                type="button"
                aria-label="Next places"
                onClick={() => nudgeRail(1)}
                className="inline-flex size-11 items-center justify-center border border-line"
              >
                <ChevronRight className="size-5" />
              </button>
            </div>
          </div>

          {filtered.length === 0 ? (
            <p className="mx-auto mt-16 max-w-7xl px-5 text-muted md:px-10">
              Nothing under that name. Try falls, gorilla, Kidepo, or bus.
            </p>
          ) : (
            <div
              ref={railRef}
              className="mt-8 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-2 md:px-10"
            >
              {filtered.map((place) => (
                <button
                  key={place.id}
                  type="button"
                  onClick={() => setOverlay({ kind: "place", id: place.id })}
                  className="group relative h-stage w-frame shrink-0 snap-start overflow-hidden text-left text-paper"
                >
                  <img
                    src={place.image}
                    alt=""
                    className={`absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105 ${place.fit}`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-6">
                    <p className="text-xs font-medium tracking-widest uppercase">{place.category}</p>
                    <h3 className="mt-2 font-display text-4xl leading-none">{place.name}</h3>
                    <p className="mt-3 max-w-sm text-sm leading-relaxed text-paper/80">{place.region}</p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="relative min-h-svh overflow-hidden bg-ink text-paper">
          <img
            src="/media/ug/bwindi-close.jpg"
            alt="Mountain gorilla in Bwindi Impenetrable National Park"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-ink/45" />
          <div className="relative mx-auto flex min-h-svh max-w-5xl flex-col justify-end px-5 py-20 md:px-10">
            <Reveal>
              <p className="text-xs font-medium tracking-widest uppercase">Conservation</p>
              <h2 className="mt-4 font-display text-chapter">
                Half the mountain gorillas left on earth live in one forest.
              </h2>
              <p className="mt-6 max-w-lg text-base leading-relaxed text-paper/85">
                Bwindi is a UNESCO forest on the edge of the Albertine Rift. The visit is short. The walk
                to earn it is not. Go with a permit, a guide, and no illusions about the mud.
              </p>
              <button
                type="button"
                onClick={() => setOverlay({ kind: "place", id: "bwindi" })}
                className="mt-8 inline-flex h-12 items-center gap-3 bg-paper px-5 text-sm font-medium text-ink transition-transform duration-150 active:scale-[0.96]"
              >
                Read Bwindi
                <ArrowRight className="size-4" />
              </button>
            </Reveal>
          </div>
        </section>

        <section id="do" className="scroll-mt-20 mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28">
          <Reveal>
            <p className="text-xs font-medium tracking-widest text-moss uppercase">Things to do</p>
            <h2 className="mt-3 max-w-3xl font-display text-chapter">Not a list of activities. A way to spend the hours.</h2>
          </Reveal>
          <div className="mt-12 grid gap-4 md:grid-cols-2">
            {experiences.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setOverlay({ kind: "place", id: item.placeId })}
                className={`group relative min-h-96 overflow-hidden text-left text-paper ${
                  item.wide ? "md:col-span-2 md:min-h-[34rem]" : ""
                }`}
              >
                <img
                  src={item.image}
                  alt=""
                  className={`absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105 ${item.fit}`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/15 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6 md:p-8">
                  <p className="text-xs font-medium tracking-widest uppercase">{item.kicker}</p>
                  <h3 className="mt-2 font-display text-4xl leading-none">{item.title}</h3>
                  <p className="mt-3 max-w-xl text-sm leading-relaxed text-paper/85">{item.text}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        <section id="seasons" className="scroll-mt-20 border-t border-line">
          <div className="mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28">
            <Reveal>
              <p className="text-xs font-medium tracking-widest text-moss uppercase">When to go</p>
              <h2 className="mt-3 max-w-3xl font-display text-chapter">Uganda does not close. It changes temperature and mud.</h2>
            </Reveal>
            <div className="mt-12 grid gap-px bg-line sm:grid-cols-2 lg:grid-cols-4">
              {seasons.map((season) => {
                const current = season.monthsHit.includes(now);
                return (
                  <article key={season.id} className="bg-paper p-6 md:p-8">
                    <p className="text-xs font-medium tracking-widest text-muted uppercase">
                      {season.months}
                    </p>
                    {current ? (
                      <p className="mt-4 text-xs font-semibold tracking-widest text-moss uppercase">
                        This season
                      </p>
                    ) : null}
                    <h3 className="mt-3 font-display text-3xl leading-none">{season.title}</h3>
                    <p className="mt-4 text-sm leading-relaxed text-muted">{season.text}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section id="country" className="bg-sand">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 md:grid-cols-12 md:px-10 md:py-28">
            <div className="md:col-span-4">
              <p className="text-xs font-medium tracking-widest text-moss uppercase">The country</p>
              <h2 className="mt-3 font-display text-chapter">North to the source, in one line.</h2>
              <p className="mt-6 text-sm leading-relaxed text-muted">
                There is no single loop that does Uganda justice. The west strings together. The north is
                its own journey. The Nile at Jinja is a morning east of the city.
              </p>
            </div>
            <ol className="md:col-span-8">
              {places.map((place, index) => (
                <li key={place.id} className="border-t border-line">
                  <button
                    type="button"
                    onClick={() => setOverlay({ kind: "place", id: place.id })}
                    className="flex w-full items-baseline justify-between gap-6 py-5 text-left"
                  >
                    <span className="w-10 shrink-0 text-sm text-muted tabular-nums">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <span className="flex-1">
                      <span className="block font-display text-2xl leading-tight md:text-3xl">
                        {place.name}
                      </span>
                      <span className="mt-1 block text-sm text-muted">{place.region}</span>
                    </span>
                    <ArrowRight className="size-4 shrink-0" />
                  </button>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="plan" className="scroll-mt-20 mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28">
          <Reveal>
            <p className="text-xs font-medium tracking-widest text-moss uppercase">Plan your trip</p>
            <h2 className="mt-3 max-w-3xl font-display text-chapter">How the journey is actually made.</h2>
          </Reveal>
          <div className="mt-12 grid gap-12 md:grid-cols-3">
            <article>
              <h3 className="font-display text-3xl">Arrive</h3>
              <p className="mt-4 text-sm leading-relaxed text-muted">
                Entebbe is the international gate, a short drive from Kampala along the lake. Give yourself
                the afternoon in the city or leave immediately for Mburo if the weekend is short.
              </p>
            </article>
            <article>
              <h3 className="font-display text-3xl">Move</h3>
              <p className="mt-4 text-sm leading-relaxed text-muted">
                The western circuit — Mburo, Queen, Bwindi, Kibale — follows tarmac for long stretches.
                Murchison is a full day north. Kidepo wants a flight or a committed 4x4 and a night you
                did not try to skip.
              </p>
            </article>
            <article>
              <h3 className="font-display text-3xl">Pay the right fee</h3>
              <p className="mt-4 text-sm leading-relaxed text-muted">
                The citizen gate is not the gorilla permit, not the boat, and not the foreign tariff.
                The table below is the gate this directory carries for October 2026.
              </p>
            </article>
          </div>

          <div className="mt-16 overflow-x-auto border-t border-line">
            <table className="w-full min-w-[40rem] text-left text-sm">
              <caption className="sr-only">Citizen park gate fees</caption>
              <thead>
                <tr className="border-b border-line text-xs tracking-widest text-muted uppercase">
                  <th className="py-4 font-medium">Place</th>
                  <th className="py-4 font-medium">Person</th>
                  <th className="py-4 font-medium">Vehicle</th>
                  <th className="py-4 font-medium">Getting there</th>
                </tr>
              </thead>
              <tbody>
                {places.map((place) => (
                  <tr key={place.id} className="border-b border-line align-top">
                    <td className="py-4 pr-4 font-medium">
                      <button
                        type="button"
                        className="text-left underline decoration-line underline-offset-4 hover:decoration-ink"
                        onClick={() => setOverlay({ kind: "place", id: place.id })}
                      >
                        {place.name}
                      </button>
                    </td>
                    <td className="py-4 pr-4">{place.entryCost}</td>
                    <td className="py-4 pr-4">{place.carCost}</td>
                    <td className="max-w-sm py-4 text-muted">{place.transportTip}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-6 max-w-3xl text-sm leading-relaxed text-muted">
            Citizen entry fees for the six savannah and forest parks are carried here as UGX 30,000 per
            person and UGX 30,000 per car, checked against Uganda Wildlife Authority gate practice for
            October 2026. Gorilla and chimpanzee permits are booked separately. Non-resident tariffs
            differ. Reconfirm before you travel — this guide is a directory, not the authority.
          </p>
        </section>

        <section className="border-t border-line bg-ink text-paper">
          <div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 md:grid-cols-12 md:px-10 md:py-28">
            <div className="md:col-span-5">
              <p className="text-xs font-medium tracking-widest uppercase">Travel better</p>
              <h2 className="mt-3 font-display text-chapter">Leave the forest as you found it.</h2>
            </div>
            <ul className="space-y-6 text-sm leading-relaxed text-paper/80 md:col-span-7">
              <li>Book gorilla and chimp time only through UWA or a licensed operator. A cheap permit is not a permit.</li>
              <li>On a trek: no flash, no food, a little distance, and your voice down. The hour is theirs.</li>
              <li>Stay on the track the guide is using. Shortcuts break the forest faster than a photograph does.</li>
              <li>Do not post a live location of a gorilla family. The rangers already know where they are.</li>
              <li>Carry the plastic back out. Fuel and water for Kidepo are part of the plan, not a surprise.</li>
            </ul>
          </div>
        </section>
      </main>

      <footer className="bg-ink px-5 py-16 text-paper md:px-10">
        <div className="mx-auto flex max-w-7xl flex-col gap-10 border-t border-paper/15 pt-10 md:flex-row md:justify-between">
          <div>
            <p className="font-display text-4xl">The Pearl Guide</p>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-paper/70">
              A digital directory of Uganda’s wild places. Photographs are documentary frames from the
              parks named, shared by their makers on Wikimedia Commons — including Giles Laurent.
            </p>
          </div>
          <div className="flex gap-10 text-sm">
            <div className="flex flex-col gap-3">
              <button type="button" onClick={() => go("places")} className="text-left">
                Places
              </button>
              <button type="button" onClick={() => go("do")} className="text-left">
                Things to do
              </button>
              <button type="button" onClick={() => go("plan")} className="text-left">
                Plan
              </button>
            </div>
            <div className="flex flex-col gap-3 text-paper/70">
              <p>Entebbe · Kampala</p>
              <p>Fees marked October 2026</p>
              <p>Citizen gate tariffs</p>
            </div>
          </div>
        </div>
      </footer>

      <Dialog.Root open={open} onOpenChange={(next) => !next && setOverlay({ kind: "none" })}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-50 bg-ink/55" />
          <Dialog.Content className="fixed inset-0 z-50 overflow-y-auto bg-paper text-ink outline-none">
            {overlay.kind === "menu" ? (
              <MenuPanel onClose={() => setOverlay({ kind: "none" })} onGo={go} />
            ) : null}
            {overlay.kind === "search" ? (
              <SearchPanel
                query={query}
                onQuery={setQuery}
                hits={searchHits}
                onOpen={(id) => setOverlay({ kind: "place", id })}
                onClose={() => setOverlay({ kind: "none" })}
              />
            ) : null}
            {overlay.kind === "trail" ? (
              <TrailPanel
                ids={trail.ids}
                onOpen={(id) => setOverlay({ kind: "place", id })}
                onRemove={trail.remove}
                onClose={() => setOverlay({ kind: "none" })}
              />
            ) : null}
            {activePlace ? (
              <PlacePanel
                place={activePlace}
                saved={trail.ids.includes(activePlace.id)}
                onToggle={() => trail.toggle(activePlace.id)}
                onClose={() => setOverlay({ kind: "none" })}
              />
            ) : null}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
  );
}

function CloseRow({ title, onClose }: { title: string; onClose: () => void }) {
  return (
    <div className="flex items-center justify-between">
      <Dialog.Title className="font-display text-3xl">{title}</Dialog.Title>
      <Dialog.Close asChild>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="inline-flex size-11 items-center justify-center border border-line"
        >
          <X className="size-5" />
        </button>
      </Dialog.Close>
    </div>
  );
}

function MenuPanel({ onClose, onGo }: { onClose: () => void; onGo: (id: string) => void }) {
  const links = [
    ["places", "Places to go"],
    ["do", "Things to do"],
    ["seasons", "When to go"],
    ["country", "The country"],
    ["plan", "Plan the journey"],
  ];
  return (
    <div className="mx-auto flex min-h-svh max-w-3xl flex-col px-5 py-6 md:px-10">
      <CloseRow title="Menu" onClose={onClose} />
      <Dialog.Description className="sr-only">Sections of the guide.</Dialog.Description>
      <nav className="mt-16 flex flex-col">
        {links.map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => onGo(id)}
            className="border-t border-line py-5 text-left font-display text-4xl"
          >
            {label}
          </button>
        ))}
      </nav>
    </div>
  );
}

function SearchPanel({
  query,
  onQuery,
  hits,
  onOpen,
  onClose,
}: {
  query: string;
  onQuery: (value: string) => void;
  hits: Place[];
  onOpen: (id: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="mx-auto min-h-svh max-w-3xl px-5 py-6 md:px-10">
      <CloseRow title="Search" onClose={onClose} />
      <Dialog.Description className="sr-only">Search parks, wildlife, and routes.</Dialog.Description>
      <input
        autoFocus
        value={query}
        onChange={(event) => onQuery(event.target.value)}
        placeholder="Gorillas, Kidepo, bus, falls…"
        className="mt-10 w-full border-b border-ink bg-transparent py-4 font-display text-4xl outline-none placeholder:text-muted"
      />
      <ul className="mt-8">
        {hits.length === 0 ? (
          <li className="py-6 text-muted">No places match. Try Nile, zebra, or Fort Portal.</li>
        ) : (
          hits.map((place) => (
            <li key={place.id} className="border-t border-line">
              <button
                type="button"
                onClick={() => onOpen(place.id)}
                className="flex w-full items-center justify-between gap-4 py-5 text-left"
              >
                <span>
                  <span className="block text-lg font-medium">{place.name}</span>
                  <span className="text-sm text-muted">{place.region}</span>
                </span>
                <ArrowRight className="size-4" />
              </button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}

function TrailPanel({
  ids,
  onOpen,
  onRemove,
  onClose,
}: {
  ids: string[];
  onOpen: (id: string) => void;
  onRemove: (id: string) => void;
  onClose: () => void;
}) {
  const saved = ids.map((id) => placeById(id)).filter((place): place is Place => Boolean(place));
  return (
    <div className="mx-auto min-h-svh max-w-3xl px-5 py-6 md:px-10">
      <CloseRow title="Your trail" onClose={onClose} />
      <Dialog.Description className="mt-4 max-w-lg text-sm leading-relaxed text-muted">
        A shortlist kept on this device. Add parks as you read, then read the road between them.
      </Dialog.Description>
      {saved.length === 0 ? (
        <p className="mt-12 text-muted">Nothing saved yet. Open a place and add it.</p>
      ) : (
        <ol className="mt-10">
          {saved.map((place, index) => (
            <li key={place.id} className="border-t border-line py-5">
              <div className="flex items-start justify-between gap-4">
                <button type="button" onClick={() => onOpen(place.id)} className="text-left">
                  <span className="text-xs text-muted tabular-nums">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <span className="mt-1 block font-display text-3xl">{place.name}</span>
                  <span className="mt-2 block text-sm text-muted">{place.transportTip}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onRemove(place.id)}
                  className="h-11 shrink-0 px-3 text-sm"
                >
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

function PlacePanel({
  place,
  saved,
  onToggle,
  onClose,
}: {
  place: Place;
  saved: boolean;
  onToggle: () => void;
  onClose: () => void;
}) {
  const frames = [place.image, ...place.gallery];
  return (
    <div className="min-h-svh md:grid md:grid-cols-2">
      <div className="relative h-80 md:h-svh md:sticky md:top-0">
        <img src={place.image} alt="" className={`h-full w-full object-cover ${place.fit}`} />
        <Dialog.Close asChild>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close place"
            className="absolute top-4 left-4 inline-flex size-11 items-center justify-center bg-paper text-ink"
          >
            <X className="size-5" />
          </button>
        </Dialog.Close>
      </div>
      <article className="px-5 py-8 md:overflow-y-auto md:px-12 md:py-14">
        <p className="text-xs font-medium tracking-widest text-moss uppercase">{place.region}</p>
        <Dialog.Title className="mt-3 font-display text-chapter">{place.name}</Dialog.Title>
        <Dialog.Description className="mt-5 text-lg leading-relaxed text-muted">
          {place.tagline}
        </Dialog.Description>
        <p className="mt-6 text-base leading-relaxed">{place.story}</p>
        <ul className="mt-6 flex flex-wrap gap-2">
          {place.highlights.map((item) => (
            <li key={item} className="bg-sand px-3 py-2 text-sm">
              {item}
            </li>
          ))}
        </ul>
        <dl className="mt-10 grid gap-6 border-t border-line pt-8 sm:grid-cols-2">
          <div>
            <dt className="text-xs tracking-widest text-muted uppercase">Citizen entry</dt>
            <dd className="mt-2 text-lg font-medium">{place.entryCost}</dd>
          </div>
          <div>
            <dt className="text-xs tracking-widest text-muted uppercase">Vehicle</dt>
            <dd className="mt-2 text-lg font-medium">{place.carCost}</dd>
          </div>
          <div className="sm:col-span-2">
            <dt className="text-xs tracking-widest text-muted uppercase">Transport</dt>
            <dd className="mt-2 leading-relaxed">{place.transportTip}</dd>
          </div>
          <div className="sm:col-span-2">
            <dt className="text-xs tracking-widest text-muted uppercase">Also know</dt>
            <dd className="mt-2 leading-relaxed text-muted">{place.permitNote}</dd>
          </div>
        </dl>
        <button
          type="button"
          onClick={onToggle}
          className="mt-8 inline-flex h-12 items-center gap-2 bg-ink px-5 text-sm font-medium text-paper transition-transform duration-150 active:scale-[0.96]"
        >
          {saved ? <Check className="size-4" /> : null}
          {saved ? "On your trail" : "Add to your trail"}
        </button>
        {frames.length > 1 ? (
          <div className="mt-10 grid gap-3 sm:grid-cols-2">
            {place.gallery.map((src) => (
              <img key={src} src={src} alt="" className="aspect-poster w-full object-cover" />
            ))}
          </div>
        ) : null}
        <p className="mt-10 text-xs tracking-widest text-muted uppercase">
          Uganda Wildlife Authority · directory note October 2026
        </p>
      </article>
    </div>
  );
}
