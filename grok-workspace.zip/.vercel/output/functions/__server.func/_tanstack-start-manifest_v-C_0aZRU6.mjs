//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C_0aZRU6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CeyitxO_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CeyitxO_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DHTEm7xY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
