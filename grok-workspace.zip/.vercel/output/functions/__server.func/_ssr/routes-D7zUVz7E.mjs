import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ChevronRight, c as ArrowRight, i as Menu, o as ChevronLeft, r as Search, s as Check, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D7zUVz7E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var places = [
	{
		id: "murchison",
		name: "Murchison Falls National Park",
		category: "Water",
		region: "North-western Uganda",
		tagline: "The Nile forced through a gorge, then a savannah that still feels unfinished.",
		story: "The river narrows to about seven metres and drops in one violent step. Above it, the northern bank is classic game country: elephants, giraffes, buffalo, lions, and long views to the delta. Most people split the day between the top of the falls, a launch to the base, and a game drive. It is a long way from Kampala, and worth the distance.",
		highlights: [
			"The falls themselves",
			"Nile launch cruise",
			"Northern-bank game drive"
		],
		entryCost: "UGX 30,000 (Citizen)",
		carCost: "UGX 30,000",
		transportTip: "Bus from Kampala to Masindi or Pakwach, or a private 4x4 via Karuma.",
		permitNote: "The launch and the falls hike sit on top of the gate fee.",
		image: "/media/ug/murchison-falls.jpg",
		gallery: ["/media/ug/falls-top.jpg", "/media/ug/murchison-bush.jpg"],
		fit: "object-center"
	},
	{
		id: "queen",
		name: "Queen Elizabeth National Park",
		category: "Savannah",
		region: "Western Uganda",
		tagline: "A channel full of hippos, crater lakes, and lions that learned the trees.",
		story: "Queen is not one view. The Kazinga Channel is a slow boat between banks of hippos, buffalo, and waterbirds. The Ishasha sector, further south, is where lions rest in fig trees. Between them: crater lakes, kob on the open plains, and the Kyambura gorge if you want chimpanzees as well. It sits on the main western highway, which is why it anchors so many loops.",
		highlights: [
			"Kazinga Channel boat",
			"Ishasha tree-climbing lions",
			"Crater lakes"
		],
		entryCost: "UGX 30,000 (Citizen)",
		carCost: "UGX 30,000",
		transportTip: "Direct highway via Mbarara–Kasese, or a public bus to Katunguru.",
		permitNote: "The boat cruise and any chimp tracking are separate from the gate.",
		image: "/media/ug/queen-baboon.jpg",
		gallery: [],
		fit: "object-center"
	},
	{
		id: "bwindi",
		name: "Bwindi Impenetrable National Park",
		category: "Primates",
		region: "South-western Uganda",
		tagline: "An ancient, steep forest holding about half the world's mountain gorillas.",
		story: "You do not drive to the gorillas. You walk, often for hours, on mud, roots, and nettle, with trackers ahead of you and a one-hour visit when you arrive. The park is split into sectors — Buhoma, Ruhija, Rushaga, Nkuringo — and the permit is not the same thing as the gate fee. Book it before you book anything else. The forest is also one of Africa's great bird places, if your knees survive the morning.",
		highlights: [
			"Mountain gorilla trek",
			"Forest walks",
			"Albertine Rift birds"
		],
		entryCost: "UGX 30,000 (Citizen)",
		carCost: "UGX 30,000",
		transportTip: "Kabale or Kisoro bus from Kampala, then a local taxi to the park gate.",
		permitNote: "A gorilla permit is booked apart from this gate fee, and it sells out.",
		image: "/media/ug/bwindi-gorilla.jpg",
		gallery: ["/media/ug/bwindi-close.jpg"],
		fit: "object-center"
	},
	{
		id: "kibale",
		name: "Kibale National Park",
		category: "Primates",
		region: "Western Uganda",
		tagline: "The primate capital: chimpanzees in a tall, bright forest near Fort Portal.",
		story: "Kibale has the highest density of primates in East Africa, and the walk people come for is chimpanzee tracking from Kanyanchu. It is usually kinder on the legs than Bwindi, and the forest feels open and loud. Bigodi wetland, just outside, is the half-day for birds and a village walk. Pair it with the crater lakes around Fort Portal rather than rushing straight back to the highway.",
		highlights: [
			"Chimpanzee tracking",
			"Bigodi wetland",
			"Thirteen primate species"
		],
		entryCost: "UGX 30,000 (Citizen)",
		carCost: "UGX 30,000",
		transportTip: "Fort Portal bus from Kampala, then a boda or taxi to Kanyanchu.",
		permitNote: "Chimpanzee permits are separate from the gate and should be reserved.",
		image: "/media/ug/kibale-chimp.jpg",
		gallery: ["/media/ug/kibale-alpha.jpg"],
		fit: "object-center"
	},
	{
		id: "kidepo",
		name: "Kidepo Valley National Park",
		category: "Savannah",
		region: "North-eastern Uganda",
		tagline: "A remote valley of ochre hills, buffalo, and animals you will not see further south.",
		story: "Kidepo is the park people describe after they have already done the others. The Narus Valley holds buffalo, elephant, zebra, and lions against a wall of mountains. Ostrich, cheetah, and bat-eared fox turn up here and almost nowhere else in the country. The road in is the point: it is long, and a 4x4 is not a suggestion. Flying to the park is the other honest option.",
		highlights: [
			"Narus Valley drives",
			"Dry mountain scenery",
			"Species rare elsewhere in Uganda"
		],
		entryCost: "UGX 30,000 (Citizen)",
		carCost: "UGX 30,000",
		transportTip: "Long-distance bus toward Kitgum or Moroto. A 4x4 is required inside the park.",
		permitNote: "Plan fuel, water, and a night. This is not a day trip from Kampala.",
		image: "/media/ug/kidepo-22.jpg",
		gallery: ["/media/ug/kidepo-1.jpg"],
		fit: "object-bottom"
	},
	{
		id: "mburo",
		name: "Lake Mburo National Park",
		category: "Savannah",
		region: "South-western Uganda",
		tagline: "The closest savannah to the capital, with zebras, a lake, and walks on foot.",
		story: "Mburo is the park you can reach before the day is gone. It is the only one in Uganda with impala, and one of the few with zebras. Boats work the lake, horses and guides work the bush, and you are allowed out of the car — which changes the scale of everything. If a first safari has to fit around a weekend, start here.",
		highlights: [
			"Zebras and impala",
			"Boat on the lake",
			"Walking safari"
		],
		entryCost: "UGX 30,000 (Citizen)",
		carCost: "UGX 30,000",
		transportTip: "Mbarara highway bus. Step off at Sanga gate or the Akageti junction.",
		permitNote: "Walks and boats are arranged at the gate and cost extra.",
		image: "/media/ug/mburo-zebra.jpg",
		gallery: [],
		fit: "object-center"
	},
	{
		id: "rwenzori",
		name: "Rwenzori Mountains National Park",
		category: "Water",
		region: "Western Uganda",
		tagline: "Glaciers on the equator. A trek, not a game drive.",
		story: "The Rwenzori are a world of their own: giant lobelia, soaking moss, and peaks the old maps called the Mountains of the Moon. This is hiking country above the Fort Portal–Kasese road. Trails are steep, weather turns in an hour, and you go with a guide. Come for the range, not for lions.",
		highlights: [
			"Guided mountain trails",
			"Afro-alpine plants",
			"Glaciated peaks"
		],
		entryCost: "Trekking tariff",
		carCost: "Ask at the trailhead",
		transportTip: "Kasese bus or train from Kampala, then a transfer to the Nyakalengija or Kilembe trailhead.",
		permitNote: "Fees follow the route and the number of days. They are not the savannah gate tariff.",
		image: "/media/ug/rwenzori.jpg",
		gallery: [],
		fit: "object-center"
	},
	{
		id: "jinja",
		name: "Jinja & the Source of the Nile",
		category: "Water",
		region: "Eastern Uganda",
		tagline: "Where the river leaves Lake Victoria. A town, not a national park.",
		story: "Jinja is the easy adventure east of Kampala: the source monument, a wide river, islands, and the rafting and kayak outfits that made the town famous. It is not a UWA savannah gate. You can be here and back in a day, or stay for the water. Go early if you want the lake calm and the viewpoint to yourself.",
		highlights: [
			"Source of the Nile",
			"River time",
			"A day east of the city"
		],
		entryCost: "Operator fees",
		carCost: "Town parking",
		transportTip: "Frequent taxis and buses from Kampala's Old Taxi Park. About two to three hours.",
		permitNote: "Rafting, cruises, and the source site are priced by the operator, not as a park gate.",
		image: "/media/ug/nile-jinja-2.jpg",
		gallery: [],
		fit: "object-center"
	}
];
var categories = [
	{
		id: "all",
		label: "All places"
	},
	{
		id: "Savannah",
		label: "Savannah"
	},
	{
		id: "Primates",
		label: "Primates"
	},
	{
		id: "Water",
		label: "Water & peaks"
	}
];
var experiences = [
	{
		id: "gorillas",
		title: "Gorilla trekking",
		kicker: "Bwindi",
		text: "One hour with a family, after a walk that can take the morning. The permit is the whole point of the trip — arrange it first.",
		placeId: "bwindi",
		image: "/media/ug/bwindi-close.jpg",
		fit: "object-center",
		wide: true
	},
	{
		id: "chimps",
		title: "Chimpanzee tracking",
		kicker: "Kibale",
		text: "A forest walk with trackers who already know which community is feeding. Quieter logistics than the gorillas, same sense of privilege.",
		placeId: "kibale",
		image: "/media/ug/kibale-alpha.jpg",
		fit: "object-center"
	},
	{
		id: "cruise",
		title: "To the top of the falls",
		kicker: "Murchison",
		text: "Stand where the Nile gathers itself, then take the launch into the spray at the bottom. Do both. They are different rivers.",
		placeId: "murchison",
		image: "/media/ug/falls-top.jpg",
		fit: "object-center"
	},
	{
		id: "drive",
		title: "A slow game drive",
		kicker: "Northern bank",
		text: "Giraffes in a green plain, tracks of elephants, and the discipline to stop the car and wait. Dawn is the honest hour.",
		placeId: "murchison",
		image: "/media/ug/murchison-bush.jpg",
		fit: "object-center"
	},
	{
		id: "walk",
		title: "Out of the vehicle",
		kicker: "Lake Mburo",
		text: "Zebras at the scale of a footpath. Mburo is one of the few parks where a walking safari is the normal way to spend the afternoon.",
		placeId: "mburo",
		image: "/media/ug/mburo-zebra.jpg",
		fit: "object-center"
	},
	{
		id: "peaks",
		title: "Above the clouds",
		kicker: "Rwenzori",
		text: "A guided trail into moss and giant plants, with weather that does not care about your itinerary. Pack for wet rock.",
		placeId: "rwenzori",
		image: "/media/ug/rwenzori.jpg",
		fit: "object-center"
	}
];
var seasons = [
	{
		id: "dry-a",
		months: "December – February",
		title: "Dry, and wide open",
		text: "Tracks are firm, grass is lower, and the savannah reads clearly. A strong time for Murchison, Queen, Kidepo, and Mburo.",
		monthsHit: [
			12,
			1,
			2
		]
	},
	{
		id: "long",
		months: "March – May",
		title: "The long rains",
		text: "The country turns deep green. Some murram roads slow down. Forest walks continue. Bring patience and a proper rain layer.",
		monthsHit: [
			3,
			4,
			5
		]
	},
	{
		id: "dry-b",
		months: "June – September",
		title: "The long dry",
		text: "The busiest, brightest window. Book gorilla permits early. Dust on the northern tracks, brilliant light on the falls.",
		monthsHit: [
			6,
			7,
			8,
			9
		]
	},
	{
		id: "short",
		months: "October – November",
		title: "Short rains, green tracks",
		text: "Showers, fewer vehicles, and gorillas that do not take the season off. Give every transfer an extra hour.",
		monthsHit: [10, 11]
	}
];
var heroSlides = [
	{
		src: "/media/ug/murchison-falls.jpg",
		place: "Murchison Falls",
		line: "The Nile, forced through a seven-metre gorge."
	},
	{
		src: "/media/ug/bwindi-gorilla.jpg",
		place: "Bwindi Impenetrable",
		line: "A forest that still keeps the mountain gorillas."
	},
	{
		src: "/media/ug/rwenzori.jpg",
		place: "The Rwenzori",
		line: "Mountains of the Moon, on the equator."
	},
	{
		src: "/media/ug/mburo-zebra.jpg",
		place: "Lake Mburo",
		line: "Savannah you can reach before lunch."
	}
];
function placeById(id) {
	return places.find((place) => place.id === id);
}
var TRAIL_KEY = "pearl-trail";
function useTrail() {
	const [ids, setIds] = (0, import_react.useState)([]);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(TRAIL_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed)) setIds(parsed.filter((item) => typeof item === "string"));
			}
		} catch {}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(TRAIL_KEY, JSON.stringify(ids));
	}, [ids, ready]);
	function toggle(id) {
		setIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	}
	function remove(id) {
		setIds((current) => current.filter((item) => item !== id));
	}
	return {
		ids,
		toggle,
		remove
	};
}
function useReveal() {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setShown(true);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				setShown(true);
				observer.disconnect();
			}
		}, { threshold: .18 });
		observer.observe(node);
		return () => observer.disconnect();
	}, []);
	return {
		ref,
		shown
	};
}
function Reveal({ children, className = "" }) {
	const { ref, shown } = useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: `reveal ${shown ? "is-in" : ""} ${className}`,
		children
	});
}
function PearlGuide() {
	const trail = useTrail();
	const [overlay, setOverlay] = (0, import_react.useState)({ kind: "none" });
	const [solid, setSolid] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const [slide, setSlide] = (0, import_react.useState)(0);
	const railRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setSolid(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const timer = window.setInterval(() => {
			setSlide((current) => (current + 1) % heroSlides.length);
		}, 6800);
		return () => window.clearInterval(timer);
	}, []);
	const filtered = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return places.filter((place) => {
			if (!(category === "all" || place.category === category)) return false;
			if (!needle) return true;
			return [
				place.name,
				place.tagline,
				place.story,
				place.region,
				place.transportTip,
				place.highlights.join(" ")
			].join(" ").toLowerCase().includes(needle);
		});
	}, [query, category]);
	const searchHits = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		if (!needle) return places;
		return places.filter((place) => [
			place.name,
			place.region,
			place.tagline,
			place.highlights.join(" ")
		].join(" ").toLowerCase().includes(needle));
	}, [query]);
	function go(id) {
		setOverlay({ kind: "none" });
		window.setTimeout(() => {
			document.getElementById(id)?.scrollIntoView({
				behavior: "smooth",
				block: "start"
			});
		}, 40);
	}
	function nudgeRail(direction) {
		const rail = railRef.current;
		if (!rail) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		rail.scrollBy({
			left: direction * Math.round(rail.clientWidth * .8),
			behavior: reduce ? "auto" : "smooth"
		});
	}
	const open = overlay.kind !== "none";
	const activePlace = overlay.kind === "place" ? placeById(overlay.id) : void 0;
	const now = (/* @__PURE__ */ new Date()).getMonth() + 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-svh bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:bg-paper focus:px-4 focus:py-2",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: `fixed inset-x-0 top-0 z-40 transition-colors duration-300 ${solid || open ? "border-b border-line bg-paper/95 text-ink" : "text-paper"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#top",
							className: "font-display text-2xl leading-none tracking-tight",
							children: "The Pearl"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "hidden items-center gap-8 text-sm font-medium md:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go("places"),
									className: "hover:text-moss",
									children: "Places"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go("do"),
									className: "hover:text-moss",
									children: "Things to do"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go("seasons"),
									className: "hover:text-moss",
									children: "Seasons"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go("plan"),
									className: "hover:text-moss",
									children: "Plan"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "inline-flex h-11 items-center gap-2 px-3 text-sm font-medium",
									onClick: () => setOverlay({ kind: "trail" }),
									children: ["Trail", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: trail.ids.length
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Search the guide",
									className: "inline-flex size-11 items-center justify-center",
									onClick: () => setOverlay({ kind: "search" }),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
										className: "size-5",
										strokeWidth: 1.75
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Open menu",
									className: "inline-flex size-11 items-center justify-center md:hidden",
									onClick: () => setOverlay({ kind: "menu" }),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
										className: "size-5",
										strokeWidth: 1.75
									})
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "main",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "top",
						className: "relative min-h-svh overflow-hidden bg-ink text-paper",
						children: [
							heroSlides.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.src,
								alt: index === slide ? item.line : "",
								"aria-hidden": index !== slide,
								className: `absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${index === slide ? "ken opacity-100" : "opacity-0"}`
							}, item.src)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-ink/20" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mx-auto flex min-h-svh max-w-7xl flex-col justify-end px-5 pt-24 pb-14 md:px-10 md:pb-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest uppercase",
										children: "The Pearl of Africa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "mt-4 max-w-5xl font-display text-hero",
										children: [
											"Make life",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											"an adventure."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 max-w-md text-base leading-relaxed text-paper/85 md:text-lg",
										children: "Uganda, where savannah, rainforest, and the only waterfall the Nile makes share one border."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-10 flex flex-wrap items-end justify-between gap-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => go("places"),
											className: "inline-flex h-12 items-center gap-3 border border-paper/40 px-5 text-sm font-medium transition-transform duration-150 active:scale-[0.96]",
											children: ["Start with the places", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "max-w-56 text-right text-sm leading-snug text-paper/80",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block font-medium text-paper",
													children: heroSlides[slide]?.place
												}), heroSlides[slide]?.line]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex gap-2",
												children: heroSlides.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": `Show ${item.place}`,
													onClick: () => setSlide(index),
													className: `h-11 w-8 ${index === slide ? "opacity-100" : "opacity-45"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block h-px w-full ${index === slide ? "bg-paper" : "bg-paper/70"}` })
												}, item.place))
											})]
										})]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto max-w-6xl px-5 py-24 md:px-10 md:py-32",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-widest text-moss uppercase",
								children: "Welcome"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-5 max-w-4xl font-display text-chapter",
								children: "A country you can cross in a day, and still not finish."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 max-w-2xl text-lg leading-relaxed text-muted",
								children: "This is a field directory, not a brochure of slogans. Six national parks with citizen gate fees, the road that actually gets you there, and the permits that are not included."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "mt-16 grid gap-10 border-t border-line pt-10 sm:grid-cols-3",
							children: [
								["10", "National parks, from a weekend lake to a two-day frontier."],
								["1,000+", "Bird species. The shoebill is only the famous one."],
								["Half", "Of the world’s remaining mountain gorillas live in Bwindi."]
							].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-display text-5xl text-ink",
								children: value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-3 max-w-xs text-sm leading-relaxed text-muted",
								children: label
							})] }, value))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "grid md:grid-cols-3",
						children: [
							{
								href: "places",
								kicker: "Places to go",
								title: "The parks",
								image: "/media/ug/kidepo-22.jpg",
								fit: "object-bottom"
							},
							{
								href: "do",
								kicker: "Things to do",
								title: "The hours that matter",
								image: "/media/ug/kibale-chimp.jpg",
								fit: "object-center"
							},
							{
								href: "plan",
								kicker: "Plan the journey",
								title: "Gates, roads, fees",
								image: "/media/ug/kidepo-1.jpg",
								fit: "object-center"
							}
						].map((door) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => go(door.href),
							className: "group relative aspect-poster min-h-80 overflow-hidden text-left text-paper",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: door.image,
									alt: "",
									className: `absolute inset-0 h-full w-full ${door.fit} object-cover transition-transform duration-700 group-hover:scale-105`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/15 to-transparent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute inset-x-0 bottom-0 p-6 md:p-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest uppercase",
										children: door.kicker
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-4xl leading-none",
										children: door.title
									})]
								})
							]
						}, door.href))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "places",
						className: "scroll-mt-20 py-20 md:py-28",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto flex max-w-7xl flex-col gap-8 px-5 md:flex-row md:items-end md:justify-between md:px-10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-widest text-moss uppercase",
									children: "Places to go"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-chapter",
									children: "Where the country opens."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: categories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setCategory(item.id),
										className: `h-11 rounded-full px-4 text-sm font-medium transition-transform duration-150 active:scale-[0.96] ${category === item.id ? "bg-ink text-paper" : "border border-line bg-paper text-ink"}`,
										children: item.label
									}, item.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto mt-8 flex max-w-7xl items-center justify-between gap-4 px-5 md:px-10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "relative block max-w-md flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "Filter places"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: query,
											onChange: (event) => setQuery(event.target.value),
											placeholder: "Search parks, gorillas, buses, fees",
											className: "h-12 w-full border border-line bg-paper pr-4 pl-11 text-sm outline-none focus:border-moss"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hidden gap-2 sm:flex",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Previous places",
										onClick: () => nudgeRail(-1),
										className: "inline-flex size-11 items-center justify-center border border-line",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Next places",
										onClick: () => nudgeRail(1),
										className: "inline-flex size-11 items-center justify-center border border-line",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
									})]
								})]
							}),
							filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-16 max-w-7xl px-5 text-muted md:px-10",
								children: "Nothing under that name. Try falls, gorilla, Kidepo, or bus."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								ref: railRef,
								className: "mt-8 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-2 md:px-10",
								children: filtered.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setOverlay({
										kind: "place",
										id: place.id
									}),
									className: "group relative h-stage w-frame shrink-0 snap-start overflow-hidden text-left text-paper",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: place.image,
											alt: "",
											className: `absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105 ${place.fit}`
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-transparent" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute inset-x-0 bottom-0 p-6",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-medium tracking-widest uppercase",
													children: place.category
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "mt-2 font-display text-4xl leading-none",
													children: place.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 max-w-sm text-sm leading-relaxed text-paper/80",
													children: place.region
												})
											]
										})
									]
								}, place.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative min-h-svh overflow-hidden bg-ink text-paper",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/media/ug/bwindi-close.jpg",
								alt: "Mountain gorilla in Bwindi Impenetrable National Park",
								className: "absolute inset-0 h-full w-full object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-ink/45" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative mx-auto flex min-h-svh max-w-5xl flex-col justify-end px-5 py-20 md:px-10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest uppercase",
										children: "Conservation"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-4 font-display text-chapter",
										children: "Half the mountain gorillas left on earth live in one forest."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 max-w-lg text-base leading-relaxed text-paper/85",
										children: "Bwindi is a UNESCO forest on the edge of the Albertine Rift. The visit is short. The walk to earn it is not. Go with a permit, a guide, and no illusions about the mud."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setOverlay({
											kind: "place",
											id: "bwindi"
										}),
										className: "mt-8 inline-flex h-12 items-center gap-3 bg-paper px-5 text-sm font-medium text-ink transition-transform duration-150 active:scale-[0.96]",
										children: ["Read Bwindi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
									})
								] })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "do",
						className: "scroll-mt-20 mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-moss uppercase",
							children: "Things to do"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-3xl font-display text-chapter",
							children: "Not a list of activities. A way to spend the hours."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-4 md:grid-cols-2",
							children: experiences.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOverlay({
									kind: "place",
									id: item.placeId
								}),
								className: `group relative min-h-96 overflow-hidden text-left text-paper ${item.wide ? "md:col-span-2 md:min-h-[34rem]" : ""}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: item.image,
										alt: "",
										className: `absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105 ${item.fit}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/15 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-x-0 bottom-0 p-6 md:p-8",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-medium tracking-widest uppercase",
												children: item.kicker
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-2 font-display text-4xl leading-none",
												children: item.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 max-w-xl text-sm leading-relaxed text-paper/85",
												children: item.text
											})
										]
									})
								]
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "seasons",
						className: "scroll-mt-20 border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-widest text-moss uppercase",
								children: "When to go"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 max-w-3xl font-display text-chapter",
								children: "Uganda does not close. It changes temperature and mud."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12 grid gap-px bg-line sm:grid-cols-2 lg:grid-cols-4",
								children: seasons.map((season) => {
									const current = season.monthsHit.includes(now);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "bg-paper p-6 md:p-8",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-medium tracking-widest text-muted uppercase",
												children: season.months
											}),
											current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-4 text-xs font-semibold tracking-widest text-moss uppercase",
												children: "This season"
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-3 font-display text-3xl leading-none",
												children: season.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-4 text-sm leading-relaxed text-muted",
												children: season.text
											})
										]
									}, season.id);
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "country",
						className: "bg-sand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-7xl gap-12 px-5 py-20 md:grid-cols-12 md:px-10 md:py-28",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest text-moss uppercase",
										children: "The country"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 font-display text-chapter",
										children: "North to the source, in one line."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 text-sm leading-relaxed text-muted",
										children: "There is no single loop that does Uganda justice. The west strings together. The north is its own journey. The Nile at Jinja is a morning east of the city."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "md:col-span-8",
								children: places.map((place, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-t border-line",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setOverlay({
											kind: "place",
											id: place.id
										}),
										className: "flex w-full items-baseline justify-between gap-6 py-5 text-left",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-10 shrink-0 text-sm text-muted tabular-nums",
												children: String(index + 1).padStart(2, "0")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block font-display text-2xl leading-tight md:text-3xl",
													children: place.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block text-sm text-muted",
													children: place.region
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 shrink-0" })
										]
									})
								}, place.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "plan",
						className: "scroll-mt-20 mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-widest text-moss uppercase",
								children: "Plan your trip"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 max-w-3xl font-display text-chapter",
								children: "How the journey is actually made."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-12 grid gap-12 md:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-3xl",
										children: "Arrive"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-sm leading-relaxed text-muted",
										children: "Entebbe is the international gate, a short drive from Kampala along the lake. Give yourself the afternoon in the city or leave immediately for Mburo if the weekend is short."
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-3xl",
										children: "Move"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-sm leading-relaxed text-muted",
										children: "The western circuit — Mburo, Queen, Bwindi, Kibale — follows tarmac for long stretches. Murchison is a full day north. Kidepo wants a flight or a committed 4x4 and a night you did not try to skip."
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-3xl",
										children: "Pay the right fee"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-sm leading-relaxed text-muted",
										children: "The citizen gate is not the gorilla permit, not the boat, and not the foreign tariff. The table below is the gate this directory carries for October 2026."
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-16 overflow-x-auto border-t border-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full min-w-[40rem] text-left text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
											className: "sr-only",
											children: "Citizen park gate fees"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "border-b border-line text-xs tracking-widest text-muted uppercase",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-4 font-medium",
													children: "Place"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-4 font-medium",
													children: "Person"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-4 font-medium",
													children: "Vehicle"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-4 font-medium",
													children: "Getting there"
												})
											]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: places.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "border-b border-line align-top",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 pr-4 font-medium",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "text-left underline decoration-line underline-offset-4 hover:decoration-ink",
														onClick: () => setOverlay({
															kind: "place",
															id: place.id
														}),
														children: place.name
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 pr-4",
													children: place.entryCost
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 pr-4",
													children: place.carCost
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "max-w-sm py-4 text-muted",
													children: place.transportTip
												})
											]
										}, place.id)) })
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-3xl text-sm leading-relaxed text-muted",
								children: "Citizen entry fees for the six savannah and forest parks are carried here as UGX 30,000 per person and UGX 30,000 per car, checked against Uganda Wildlife Authority gate practice for October 2026. Gorilla and chimpanzee permits are booked separately. Non-resident tariffs differ. Reconfirm before you travel — this guide is a directory, not the authority."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "border-t border-line bg-ink text-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-7xl gap-10 px-5 py-20 md:grid-cols-12 md:px-10 md:py-28",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-widest uppercase",
									children: "Travel better"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-chapter",
									children: "Leave the forest as you found it."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "space-y-6 text-sm leading-relaxed text-paper/80 md:col-span-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Book gorilla and chimp time only through UWA or a licensed operator. A cheap permit is not a permit." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "On a trek: no flash, no food, a little distance, and your voice down. The hour is theirs." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stay on the track the guide is using. Shortcuts break the forest faster than a photograph does." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do not post a live location of a gorilla family. The rangers already know where they are." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Carry the plastic back out. Fuel and water for Kidepo are part of the plan, not a surprise." })
								]
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "bg-ink px-5 py-16 text-paper md:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-col gap-10 border-t border-paper/15 pt-10 md:flex-row md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl",
						children: "The Pearl Guide"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-sm leading-relaxed text-paper/70",
						children: "A digital directory of Uganda’s wild places. Photographs are documentary frames from the parks named, shared by their makers on Wikimedia Commons — including Giles Laurent."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-10 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go("places"),
									className: "text-left",
									children: "Places"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go("do"),
									className: "text-left",
									children: "Things to do"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go("plan"),
									className: "text-left",
									children: "Plan"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 text-paper/70",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Entebbe · Kampala" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Fees marked October 2026" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Citizen gate tariffs" })
							]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: (next) => !next && setOverlay({ kind: "none" }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/55" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed inset-0 z-50 overflow-y-auto bg-paper text-ink outline-none",
					children: [
						overlay.kind === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPanel, {
							onClose: () => setOverlay({ kind: "none" }),
							onGo: go
						}) : null,
						overlay.kind === "search" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchPanel, {
							query,
							onQuery: setQuery,
							hits: searchHits,
							onOpen: (id) => setOverlay({
								kind: "place",
								id
							}),
							onClose: () => setOverlay({ kind: "none" })
						}) : null,
						overlay.kind === "trail" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrailPanel, {
							ids: trail.ids,
							onOpen: (id) => setOverlay({
								kind: "place",
								id
							}),
							onRemove: trail.remove,
							onClose: () => setOverlay({ kind: "none" })
						}) : null,
						activePlace ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlacePanel, {
							place: activePlace,
							saved: trail.ids.includes(activePlace.id),
							onToggle: () => trail.toggle(activePlace.id),
							onClose: () => setOverlay({ kind: "none" })
						}) : null
					]
				})] })
			})
		]
	});
}
function CloseRow({ title, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
			className: "font-display text-3xl",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				"aria-label": "Close",
				className: "inline-flex size-11 items-center justify-center border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			})
		})]
	});
}
function MenuPanel({ onClose, onGo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-svh max-w-3xl flex-col px-5 py-6 md:px-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseRow, {
				title: "Menu",
				onClose
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				className: "sr-only",
				children: "Sections of the guide."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-16 flex flex-col",
				children: [
					["places", "Places to go"],
					["do", "Things to do"],
					["seasons", "When to go"],
					["country", "The country"],
					["plan", "Plan the journey"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onGo(id),
					className: "border-t border-line py-5 text-left font-display text-4xl",
					children: label
				}, id))
			})
		]
	});
}
function SearchPanel({ query, onQuery, hits, onOpen, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-svh max-w-3xl px-5 py-6 md:px-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseRow, {
				title: "Search",
				onClose
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				className: "sr-only",
				children: "Search parks, wildlife, and routes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				autoFocus: true,
				value: query,
				onChange: (event) => onQuery(event.target.value),
				placeholder: "Gorillas, Kidepo, bus, falls…",
				className: "mt-10 w-full border-b border-ink bg-transparent py-4 font-display text-4xl outline-none placeholder:text-muted"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8",
				children: hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-6 text-muted",
					children: "No places match. Try Nile, zebra, or Fort Portal."
				}) : hits.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen(place.id),
						className: "flex w-full items-center justify-between gap-4 py-5 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-lg font-medium",
							children: place.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: place.region
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				}, place.id))
			})
		]
	});
}
function TrailPanel({ ids, onOpen, onRemove, onClose }) {
	const saved = ids.map((id) => placeById(id)).filter((place) => Boolean(place));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-svh max-w-3xl px-5 py-6 md:px-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseRow, {
				title: "Your trail",
				onClose
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				className: "mt-4 max-w-lg text-sm leading-relaxed text-muted",
				children: "A shortlist kept on this device. Add parks as you read, then read the road between them."
			}),
			saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-12 text-muted",
				children: "Nothing saved yet. Open a place and add it."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-10",
				children: saved.map((place, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-t border-line py-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpen(place.id),
							className: "text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted tabular-nums",
									children: String(index + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block font-display text-3xl",
									children: place.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block text-sm text-muted",
									children: place.transportTip
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onRemove(place.id),
							className: "h-11 shrink-0 px-3 text-sm",
							children: "Remove"
						})]
					})
				}, place.id))
			})
		]
	});
}
function PlacePanel({ place, saved, onToggle, onClose }) {
	const frames = [place.image, ...place.gallery];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-svh md:grid md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-80 md:h-svh md:sticky md:top-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: place.image,
				alt: "",
				className: `h-full w-full object-cover ${place.fit}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					"aria-label": "Close place",
					className: "absolute top-4 left-4 inline-flex size-11 items-center justify-center bg-paper text-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "px-5 py-8 md:overflow-y-auto md:px-12 md:py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-moss uppercase",
					children: place.region
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "mt-3 font-display text-chapter",
					children: place.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-5 text-lg leading-relaxed text-muted",
					children: place.tagline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-base leading-relaxed",
					children: place.story
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 flex flex-wrap gap-2",
					children: place.highlights.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "bg-sand px-3 py-2 text-sm",
						children: item
					}, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-10 grid gap-6 border-t border-line pt-8 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs tracking-widest text-muted uppercase",
							children: "Citizen entry"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-2 text-lg font-medium",
							children: place.entryCost
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs tracking-widest text-muted uppercase",
							children: "Vehicle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-2 text-lg font-medium",
							children: place.carCost
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Transport"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2 leading-relaxed",
								children: place.transportTip
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Also know"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2 leading-relaxed text-muted",
								children: place.permitNote
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onToggle,
					className: "mt-8 inline-flex h-12 items-center gap-2 bg-ink px-5 text-sm font-medium text-paper transition-transform duration-150 active:scale-[0.96]",
					children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : null, saved ? "On your trail" : "Add to your trail"]
				}),
				frames.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-3 sm:grid-cols-2",
					children: place.gallery.map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "",
						className: "aspect-poster w-full object-cover"
					}, src))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-xs tracking-widest text-muted uppercase",
					children: "Uganda Wildlife Authority · directory note October 2026"
				})
			]
		})]
	});
}
var SplitComponent = PearlGuide;
//#endregion
export { SplitComponent as component };
